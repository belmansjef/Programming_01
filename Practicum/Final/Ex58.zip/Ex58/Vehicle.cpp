#include "pch.h"
#include "Vehicle.h"
/*
Vehicle::Vehicle(int id)
{

}

void Vehicle::Reset()
{

}

Vehicle::~Vehicle()
{

}

void Vehicle::Update(float elapsedSec, float windowWidth)
{

}

void Vehicle::Draw()
{

}

bool Vehicle::IsIntersecting(const Point2f& pt)
{

}

void Vehicle::SetActive(bool isActive)
{

}

void Vehicle::SetYPos(float posY)
{

}
*/